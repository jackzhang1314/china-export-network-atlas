export const nbs = "https://www.stats.gov.cn/sj/zxfbhjd/202602/t20260228_1962662.html";
export const nbsEnglish = "https://www.stats.gov.cn/english/PressRelease/202602/t20260228_1962661.html";
export const tradeTotal = 269890;
export const tradeGrowth = 6.1;
export const electricalTotal = 164683;

export const groups = {
  digital: "电子与家电",
  industrial: "装备与能源",
  materials: "材料与供应链",
  consumer: "消费与轻工",
};

function national(item, amount, growth) {
  return { item, amount, growth, unit: "亿元", source: nbs, publisher: "国家统计局公报 · 表11", national: true };
}

function sector(item, amount, growth, unit, publisher, source) {
  return { item, amount, growth, unit, publisher, source, national: false };
}

export const industries = [
  {
    id: "computing", group: "digital", name: "计算机与服务器", english: "Computing & Servers",
    metrics: [national("自动数据处理设备及其零部件", 14530, -0.8)],
    scope: "出口统计覆盖自动数据处理设备及零部件。案例聚焦集和诚的工业计算机与新华三的企业服务器，网络设备作为配套观察。",
    buyer: "企业 IT、系统集成商与渠道商分别关心型号供货、配置兼容、批量采购价格、维保与本地技术支持。",
    compare: "集和诚用西语和葡语子域做工控机选型，新华三把当地技术服务与渠道合作嵌入全球主域。两个样本的共同投入，是可复用的型号体系与本地服务内容。",
    apply: "以产品型号为核心维护参数、驱动和文档。国家页保留当地供货清单、服务窗口及企业采购入口。渠道商和终端买家的入口应有不同的字段。",
  },
  {
    id: "components", group: "digital", name: "芯片与显示器件", english: "Semiconductors & Displays",
    metrics: [national("集成电路", 14442, 27.4), national("液晶平板显示模组", 2306, 11.7)],
    scope: "分别采用两个国家统计局商品项。MCU 与车载显示为对应案例切面，两个指标不合为一个销售市场。",
    buyer: "设计工程师通过料号、封装、接口、工作温度和长期供应条件筛选。工程样品、选型资料、技术沟通和分销库存是后续决策环节。",
    compare: "兆易创新按工程任务拆出开发者站，京东方精电按区域工程支持拆出英国入口。前者适合共同型号和文档，后者适合需要客户沟通的定制显示。",
    apply: "先建立能按料号访问的产品详情、规格书和版本管理，再按当地服务差异分出支持入口。询盘应带上项目阶段、数量和设计要求。",
  },
  {
    id: "phones", group: "digital", name: "手机", english: "Mobile Phones",
    metrics: [national("手机", 8696, -9)],
    scope: "出口额为手机商品项。案例聚焦 ODM 工厂自己的外贸独立站和区域客户对接。",
    buyer: "品牌采购与通信渠道关心研发能力、型号定制、制式、量产计划、可选产地和交付支持。",
    compare: "天珑在全球 ODM 站之外有美国域，华勤以中英文产品与全球基地页集中介绍交付能力。采购分工解释了两种选择。",
    apply: "把产品方案、可定制范围、样机阶段、量产与市场交付写给企业采购。区域站强调当地项目对接，全球站维护统一能力说明。",
  },
  {
    id: "appliances", group: "digital", name: "家用电器", english: "Home Appliances",
    metrics: [sector("家用电器", 6888.5, -3.3, "亿元", "中国家用电器研究院 · 海关口径", "https://cheari.ac.cn/index.php/Show/cid/104/aid/4136")],
    scope: "行业报告引用全国海关统计。以大家电与空调经营为案例，金额涵盖该报告列示的家电总体口径。",
    buyer: "经销商和项目采购常查容量、能效、电源、安装尺寸、说明书和当地服务。家电还需要国家层面的售后与备件分配。",
    compare: "美的德国与海尔欧洲暖通站面向安装商和项目采购。澳柯玛主要用海外站集中展示家电和商用制冷设备。",
    apply: "把同系列机型的市场规格差异做成字段，型号 PDF 与安装说明随本地页面呈现。客户入口按购买、安装或渠道合作分流。",
  },
  {
    id: "machinery", group: "industrial", name: "工程机械", english: "Construction Machinery",
    metrics: [sector("工程机械产品（含主机和零部件）", 602.3, 13.9, "亿美元", "中国机电产品进出口商会 · 海关口径", "https://www.cccme.org.cn/model5-1/news/details.aspx?classid=3AFFFDC5D50285DC&id=FA31909AA38635DB58A6BB39B8975578&xgid=F868932F64EB7AAF")],
    scope: "商会报告同时给出 2025 年亚洲 251.6 亿美元、欧洲 129.6 亿美元、非洲 88.9 亿美元的样本地区出口数据。金额反映已有货物流向，市场页优先级还要考虑当地渠道与服务。",
    buyer: "租赁商、承包商和经销商按吨位、工况、机型及附件采购。交付后，他们还关心零件、维修、培训及当地人员是否可以到场。",
    compare: "三一的印度入口同时承接选型、经销与配件。徐工智利把挖掘机入口连到西语报价。中联的欧洲和土耳其入口把区域产品及服务放在不同网站。",
    apply: "先做适用于当地的主机系列，给规格和应用配上明确的报价或经销入口。备件、保修和本地联系人直接对应机器型号。",
  },
  {
    id: "vehicles", group: "industrial", name: "汽车与商用车", english: "Vehicles & Commercial Vehicles",
    metrics: [national("汽车（包括底盘）", 10183, 22)],
    scope: "统计项涵盖汽车及底盘。案例对照公交大客户、商用车进口商和单车型专题，轮胎另列。",
    buyer: "公交与客运采购要核对乘员配置、线路和维保方式。商用卡车看载重、上装、续航、车队交付和总使用成本。",
    compare: "宇通以独立欧洲域集中对接项目和维保。MAXUS 的北欧与波兰站展示进口商怎样参与国家网站。福田波兰以单车系专题匹配应用场景。",
    apply: "只展示可在当地销售、交付和维护的车型。工厂可以借鉴按国家设定销售责任、用途内容以及咨询去向的做法。",
  },
  {
    id: "tires", group: "industrial", name: "轮胎", english: "Tires",
    metrics: [sector("橡胶轮胎", 1677.03, 2, "亿元", "中国橡胶工业协会 · 海关口径", "https://www.cria.org.cn/a/2017043170962018306")],
    scope: "协会称其中新的充气橡胶轮胎为 1,611.23 亿元，汽车橡胶轮胎为 1,376.12 亿元。两个子口径有交叉，分别用于说明结构。",
    buyer: "进口商、胎店、车队与主机厂按尺寸、负荷和速度级别找产品，也要核对配套、使用场景、产品标签和当地服务。",
    compare: "玲珑展示集团销售与德国经销入口分工。赛轮美国品牌站负责找胎与门店，欧洲产品信息可以与供应方公开标签交叉核对。",
    apply: "让产品页覆盖规格、适配车辆、花纹与应用，并按型号维护当地可公开资料。分开设计经销合作、终端找店和质保入口。",
  },
  {
    id: "energy", group: "industrial", name: "光伏与储能", english: "Solar & Energy Storage",
    metrics: [sector("光伏产品（硅片、电池片、组件）", 294.5, -8, "亿美元", "中国机电产品进出口商会 · 海关口径", "https://www.cccme.org.cn/model5-1/news/details.aspx?classid=7685F2FA1E54A7F5&id=B31FE14D32F9104E20D30B61AB70D332&xgid=F868932F64EB7AAF")],
    scope: "指标覆盖硅片、电池片、光伏组件。阳光电源和宁德时代作为逆变器与电池的相邻产业案例，观察当地维护及项目交接。",
    buyer: "安装商、渠道商、项目集成商按系列、功率、接口与项目规模筛选。数据表、安装手册、合规文件、技术支持和运维能力影响下一步。",
    compare: "晶科美国与欧洲使用独立区域域名，阳光电源将区域服务和办公窗口放进主域，宁德时代的德语服务页按地区和业务提供联系信息。",
    apply: "产品文件用型号和市场归档，保留版本与适用范围。以当地服务工程师、安装商支持或项目咨询为页面目标，根据覆盖能力规划独立站。",
  },
  {
    id: "textiles", group: "materials", name: "纺织纱线与面料", english: "Textiles & Yarns",
    metrics: [national("纺织纱线、织物及其制品", 10205, 1)],
    scope: "纱线、面料、纺织制品按国家公报口径观察。生产基地所在国和网站目标市场是两类证据，案例单独展示。",
    buyer: "织造厂、服装品牌采购团队查纤维成分、纱支、克重、色牢度、色卡、起订量、样品与产地。跨国工厂还涉及各地产能和打样联系。",
    compare: "华孚说明纱线与产地，绍兴优楚侧重贸易与交付，云虹做英文面料目录，森蓝进一步用西语服务选布。",
    apply: "为产品做结构化成分和工艺资料，按买家搜索区分原料、规格与用途。多个地区有真实选型、打样及服务差异时，才有充分理由各自建页。",
  },
  {
    id: "apparel", group: "consumer", name: "服装与衣着附件", english: "Apparel",
    metrics: [national("服装及衣着附件", 10822, -4.4)],
    scope: "出口额引用服装及衣着附件商品项。案例均面向品牌或批发商的定制生产，覆盖运动服 OEM、独立品牌打样和成衣供应链。",
    buyer: "服装品牌采购关注面辅料、工艺、样衣、品控、最小订量与交付周期。不同类型的定制需要提交不同资料。",
    compare: "宏裕公开不同定制层级的起订与打样，Yotex 公开运动服项目与工厂联系，Yumulin 在同一主域做了多语采购。申洲作为成衣供应链对照。",
    apply: "工厂可把尺码、面料、工艺和打样条件结构化，按市场补充交付约束。把国家页的动作收敛到索样、拿规格或者批量询价。",
  },
  {
    id: "packaging", group: "materials", name: "塑料制品与包装", english: "Plastics & Packaging",
    metrics: [national("塑料制品", 7487, -0.8)],
    scope: "金额是塑料制品整体口径。美妆塑料包装是直接子类，纸、纤维包装及 PDT R US 是产品获客结构对照。",
    buyer: "品牌方和灌装厂从容量、口径、材质、起订量、结构和工艺进入采购。不同国家的样品快递与可供应方案也会影响联系。",
    compare: "HCP 通过法国 SIMP 承接特定涂抹器技术。裕同澳洲突出纤维包装本地业务。PDT R US 网络用国家和产品组合建立多个入口。",
    apply: "拿同一款产品做对照，检查两国页面的尺寸、材料、交期和样品入口是否真的有差异。产品分站需要清晰的产品边界与持续内容能力。",
  },
  {
    id: "steel", group: "materials", name: "钢材", english: "Steel Products",
    metrics: [national("钢材", 5911, -0.7)],
    scope: "2025 年钢材数量 11,902 万吨，同比增长 7.5%。数量增加伴随金额略降，适合把规模与金额增速一起阅读。",
    buyer: "工程采购用牌号、执行标准、尺寸、公差及表面处理筛选，之后需要材质证明、交期与贸易条款，并区分现货与产线定做。",
    compare: "宝钢欧洲站由区域公司说明销售和机构职责。青山公开列出旗下成员网站及集团关系，适合观察大型集团按业务拆分入口的方式。",
    apply: "先做规范页、牌号对照、材料证明和报价资料。地域页承载库存、交付和合适的责任主体，帮助买家从材料识别走向采购。",
  },
  {
    id: "furniture", group: "consumer", name: "家具与家居", english: "Furniture & Homewares",
    metrics: [national("家具及其零件", 4559, -5.6)],
    scope: "出口按家具及零件计。两个样本覆盖办公空间项目与家具批发。",
    buyer: "经销商、办公项目和批发采购分别关注材质、尺寸、安装和交货。查看当地展厅及交付范围，可以更快判断项目能否承接。",
    compare: "圣奥的美国区域页结合展厅、产品及当地项目。致欧把 OEM 与批量贸易放到独立 B2B 域，集团域提供公开关系。",
    apply: "优先建立统一产品和配件的规格数据，再以本地仓配、售后与采购窗口分市场。做 B2B 时强调工程案例、组合规格和批量交付。",
  },
  {
    id: "footwear", group: "consumer", name: "鞋靴", english: "Footwear",
    metrics: [national("鞋靴", 2975, -10.8)],
    scope: "公报鞋靴项包括多种鞋类。案例围绕鞋厂的代工、大货订单和贸易端，不用消费品牌商城代替工厂样本。",
    buyer: "品牌采购核对鞋楦、尺码、材料、鞋底、工艺、数量和样期。能否从纸样到成品共同开发，会影响选择哪家供应商。",
    compare: "Union Shoes 讲设计、打样到量产，环旅说明工厂与外贸公司如何分工。DOING 还用西语和法语版说明鞋型及贴牌合作。",
    apply: "用鞋型、适用场景和工艺做目录，每页给出需要买家提交的规格与开发材料。若同一鞋型服务多国，可为不同尺码标准和渠道规则补充当地页。",
  },
  {
    id: "luggage", group: "consumer", name: "箱包与背包", english: "Luggage & Bags",
    metrics: [national("箱包及类似容器", 2140, -12.9)],
    scope: "公报使用箱包及类似容器口径。样本聚焦软包、旅行包和 OEM 订单，同时区分贸易与生产角色。",
    buyer: "品牌、批发商和礼品采购常按容量、材质、附件、目标价格、起订量、标识和定制包装筛选。",
    compare: "君源的贸易站公开生产合作和报价所需资料，捷瑞直接说明制造及出口并按箱包用途组织。Elegant 则用西语语言版展开 OEM 选型与批量采购。",
    apply: "可将常用材料、部件、工艺及用途做成产品和方案资料。询盘应便于描述打样、目标市场、数量、运输及上市节奏。",
  },
  {
    id: "toys", group: "consumer", name: "玩具", english: "Toys",
    metrics: [national("玩具", 2493, -12.1)],
    scope: "出口额按玩具商品项。案例观察制造商、出口贸易团队与外部经销，独立工厂可借鉴产品和经销资料的组织。",
    buyer: "分销商看品牌授权、适龄、包装、条码、商品目录和最低订货条件。产品说明、备件和售后条件也关系到渠道能否长期供货。",
    compare: "Double E 公开经销商目录。Zhorya 与 Leemook 单独运营贸易和工厂网站，有互相对应的公开主体说明。",
    apply: "按系列和年龄维护产品资料，区分说明、配件（售后）与经销申请。各市场的授权和合规信息由实际主体核定后公开。",
  },
  {
    id: "containers", group: "industrial", name: "集装箱与特种箱", english: "Containers & Special Equipment",
    metrics: [national("集装箱", 972, -19.9)],
    scope: "公报统计集装箱出口。标准干箱、冷藏箱和定制特种箱具有不同选型与询盘逻辑，案例覆盖从集团到工厂的分工。",
    buyer: "航运、租赁、工程集成商需要箱型、尺寸、制冷或专用设备接口、应用环境、交付地与生产周期。",
    compare: "中集在集团外保留特种箱工厂入口。胜狮以英文产品目录和在华工厂资料集中承接项目型采购，适合与多域工厂模式对照。",
    apply: "以箱型、工况和定制条件组织页面，把询盘导向对应生产基地或区域团队。尺寸与选件表应帮助买家说明用途、数量、交付地。",
  },
];

export const seoSource = "https://developers.google.com/search/docs/specialty/international/managing-multi-regional-sites";
