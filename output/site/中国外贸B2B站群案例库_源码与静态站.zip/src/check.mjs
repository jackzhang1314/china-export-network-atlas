import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { industries } from "../content/industries.mjs";
import { digitalCases } from "../content/cases-digital.mjs";
import { industrialCases } from "../content/cases-industrial.mjs";
import { materialsCases } from "../content/cases-materials.mjs";
import { consumerCases } from "../content/cases-consumer.mjs";

const root = fileURLToPath(new URL("../dist", import.meta.url));
const cases = [...digitalCases, ...industrialCases, ...materialsCases, ...consumerCases];
const content = path => readFileSync(resolve(root, path), "utf8");
const htmlFiles = readdirSync(root, { recursive: true }).filter(path => path.endsWith(".html"));
const knownLinks = new Map();
assert.equal(htmlFiles.length, industries.length + cases.length + 5);
for (const file of htmlFiles) {
  const html = content(file);
  assert.match(html, /<html lang="zh-CN">/u, file);
  assert.equal([...html.matchAll(/<h1(?:\s[^>]*)?>/g)].length, 1, file);
  assert.match(html, /<meta name="description" content="[^"]+"/);
  const path = file === "index.html" ? "/" : "/" + file.replace(/index\.html$/, "");
  for (const [, value] of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    if (value.startsWith("https://")) continue;
    assert(value.startsWith("/") || value.startsWith("#"), `Unexpected link in ${file}: ${value}`);
    const url = new URL(value, "https://example.test" + path);
    let target = resolve(root, "." + url.pathname);
    if (existsSync(target) && statSync(target).isDirectory()) target = resolve(target, "index.html");
    assert(existsSync(target), `${file}: missing ${value}`);
    if (url.hash) {
      if (!knownLinks.has(target)) {
        const text = readFileSync(target, "utf8");
        knownLinks.set(target, new Set([...text.matchAll(/ id="([^"]+)"/g)].map(match => match[1])));
      }
      assert(knownLinks.get(target).has(url.hash.slice(1)), `${file}: missing fragment ${value}`);
    }
  }
}

for (const item of cases) {
  const html = content(`cases/${item.id}/index.html`);
  for (const entry of [...item.sites, ...item.sources]) {
    assert(html.includes(`href="${entry.url.replaceAll("&", "&amp;")}"`), `${item.id} missing ${entry.label}`);
  }
}
assert.equal(content("data/b2b-site-links.csv").trim().split(/\r?\n/).length, 1 + cases.reduce((sum, item) => sum + item.sites.length, 0));
assert.equal(content("data/export-metrics.csv").trim().split(/\r?\n/).length, 1 + industries.reduce((sum, item) => sum + item.metrics.length, 0));
assert.match(content("404.html"), /name="robots" content="noindex"/);
console.log(`Checked ${htmlFiles.length} HTML pages, internal anchors, case destinations, and both CSV downloads.`);
