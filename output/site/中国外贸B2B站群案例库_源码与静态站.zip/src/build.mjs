import { cpSync, mkdirSync, mkdtempSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { digitalCases } from "../content/cases-digital.mjs";
import { industrialCases } from "../content/cases-industrial.mjs";
import { materialsCases } from "../content/cases-materials.mjs";
import { consumerCases } from "../content/cases-consumer.mjs";
import { electricalTotal, groups, industries, nbs, nbsEnglish, seoSource, tradeGrowth, tradeTotal } from "../content/industries.mjs";
import { evidenceLevels, leadTypes, structures } from "../content/schema.mjs";
import { linkAvailability } from "../content/link-availability.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const cases = [...digitalCases, ...industrialCases, ...materialsCases, ...consumerCases];
const byIndustry = new Map(industries.map(item => [item.id, item]));
const siteName = "中国外贸 B2B 站群案例库";
const checked = "2026-11-17";
const number = new Intl.NumberFormat("zh-CN", { maximumFractionDigits: 2 });
const counts = {
  industries: industries.length,
  cases: cases.length,
  sites: cases.flatMap(item => item.sites).length,
  businessSamples: cases.filter(item => item.structure === "central").length,
};
const featured = ["jhctech", "tinno", "zhorya"].map(id => cases.find(item => item.id === id));
const nationalMetrics = industries.flatMap(industry => industry.metrics
  .filter(metric => metric.national).map(metric => ({ ...metric, industry }))
).sort((a, b) => b.amount - a.amount);
const sectorMetrics = industries.flatMap(industry => industry.metrics
  .filter(metric => !metric.national).map(metric => ({ ...metric, industry }))
);

function escape(value) {
  const characters = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  return String(value).replace(/[&<>"']/g, char => characters[char]);
}

function link(href, label, className = "") {
  return `<a href="${escape(href)}"${className ? ` class="${escape(className)}"` : ""}${href.endsWith(".csv") ? " download" : ""}>${escape(label)}</a>`;
}

function external(href, label, className = "") {
  return `<a href="${escape(href)}" class="external ${escape(className)}" target="_blank" rel="noopener noreferrer">${escape(label)} <span aria-hidden="true">↗</span><span class="sr-only">（在新标签页打开）</span></a>`;
}

function iconArrow() {
  return `<span class="arrow" aria-hidden="true">→</span>`;
}

function button(href, label, secondary = false) {
  return `<a class="button${secondary ? " button-secondary" : ""}" href="${escape(href)}">${escape(label)}${iconArrow()}</a>`;
}

function industryPath(item) { return `/industries/${item.id}/`; }
function casePath(item) { return `/cases/${item.id}/`; }
function signed(growth) { return `${growth > 0 ? "+" : growth < 0 ? "−" : ""}${number.format(Math.abs(growth))}%`; }
function host(url) { return new URL(url).host.replace(/^www\./, ""); }
function ownCases(industry) { return cases.filter(item => item.industry === industry.id); }
function availability(url) {
  return linkAvailability[url] ? `<small class="availability">${escape(linkAvailability[url])}</small>` : "";
}

function frame({ title, description, current, content, script = false, robots = "" }) {
  const navigation = [{ id: "industries", url: "/industries/", label: "品类研究" }, { id: "cases", url: "/cases/", label: "B2B 案例" }, { id: "method", url: "/methodology/", label: "研究方法" }];
  const nav = navigation.map(item => `<a href="${item.url}"${current === item.id ? ' aria-current="page"' : ""}>${item.label}</a>`).join("");
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escape(title)}</title>
  <meta name="description" content="${escape(description)}">
  <meta name="theme-color" content="#101e38">
  ${robots ? `<meta name="robots" content="${robots}">` : ""}
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="/assets/site.css">
  ${script ? '<script src="/assets/filters.js" defer></script>' : ""}
</head>
<body>
  <a class="skip" href="#main">跳到正文</a>
  <header class="site-header">
    <div class="shell header-inner">
      <a class="brand" href="/" aria-label="出口站群研究首页"><span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i></span><span>出口站群<span class="brand-tag">研究</span></span></a>
      <nav class="nav" aria-label="网站导航">${nav}</nav>
      ${link("/data/b2b-site-links.csv", "下载数据", "nav-download")}
    </div>
  </header>
  <main id="main">${content}</main>
  <footer class="site-footer">
    <div class="shell foot-layout">
      <div><a class="brand foot-brand" href="/"><span class="brand-mark" aria-hidden="true"><i></i><i></i><i></i></span><span>出口站群<span class="brand-tag">研究</span></span></a>
      <p>按中国出口品类研究工厂与外贸公司的独立站。</p></div>
      <div class="foot-links">${link("/industries/", "品类研究")}${link("/cases/", "B2B 案例")}${link("/methodology/", "来源与口径")}${link("/data/b2b-site-links.csv", "案例网址 CSV")}</div>
      <p class="foot-meta">出口数据 2025 年度 <span aria-hidden="true">/</span> 网站资料核对 ${checked}</p>
    </div>
  </footer>
</body>
</html>
`;
}

function crumb(items) {
  const values = [{ url: "/", label: "首页" }, ...items];
  return `<nav class="crumb" aria-label="当前位置"><ol>${values.map(item => `<li>${item.url ? link(item.url, item.label) : `<span aria-current="page">${escape(item.label)}</span>`}</li>`).join("")}</ol></nav>`;
}

function intro(kicker, title, description, crumbs = "") {
  return `<div class="page-intro"><div class="shell">${crumbs}<p class="eyebrow">${escape(kicker)}</p><h1>${escape(title)}</h1><p class="page-deck">${escape(description)}</p></div></div>`;
}

function countLine() {
  const fields = [
    [number.format(tradeTotal / 10000), "万亿元", "2025 年中国货物出口"],
    [counts.industries, "个", "重点出口品类"],
    [counts.cases, "组", "B2B 网站案例与对照"],
    [counts.sites, "条", "公开采购与业务链接"],
  ];
  return `<dl class="stats shell">${fields.map(([value, unit, label]) => `<div><dt>${escape(label)}</dt><dd>${value}<span>${unit}</span></dd></div>`).join("")}</dl>`;
}

function tradeChart(metrics, className = "") {
  return `<ol class="trade-bars ${className}">${metrics.map(item => `<li>
    <a href="${industryPath(item.industry)}"><span>${escape(item.item)}</span><b>${number.format(item.amount)}</b></a>
    <meter min="0" max="${nationalMetrics[0].amount}" value="${item.amount}" aria-label="${escape(item.item + "出口额，亿元")}">${number.format(item.amount)}</meter>
  </li>`).join("")}</ol>`;
}

function card(item) {
  const industry = byIndustry.get(item.industry);
  const searchable = [item.name, item.english, item.title, item.summary, industry.name, item.sites.map(site => [site.market, site.language, site.label, host(site.url)].join(" ")).join(" ")].join(" ");
  return `<article class="case-card" data-card data-industry="${escape(item.industry)}" data-structure="${escape(item.structure)}" data-lead="${escape(item.lead)}" data-index="${escape(searchable)}">
    <div class="card-meta"><span class="tag">${escape(leadTypes[item.lead])}</span><span>${escape(industry.name)}</span></div>
    <h3><a href="${casePath(item)}">${escape(item.name)}${iconArrow()}</a></h3>
    <p class="case-card-title">${escape(item.title)}</p>
    <p>${escape(item.summary)}</p>
    <div class="card-end"><span>${escape(structures[item.structure].name)}</span><span>${item.sites.length} 条入口</span></div>
  </article>`;
}

function industryCard(item) {
  const metric = item.metrics[0];
  return `<article class="industry-card" data-card data-group="${escape(item.group)}">
    <div class="card-meta">${escape(groups[item.group])}</div>
    <h3><a href="${industryPath(item)}">${escape(item.name)}${iconArrow()}</a></h3>
    <p>${escape(metric.item)}</p>
    <div class="industry-card-bottom"><span class="fig-small">${number.format(metric.amount)} <span>${escape(metric.unit)}</span></span><span>${ownCases(item).length} 组案例</span></div>
  </article>`;
}

function home() {
  return frame({
    title: siteName,
    description: "从中国重点出口商品找到外贸 B2B 独立站，按行业、站点结构和采购入口比较制造商、贸易公司与海外业务案例。",
    content: `<section class="hero shell">
      <div class="hero-copy">
        <p class="eyebrow"><span class="signal"></span> 中国出口品类研究 <span class="hero-year">2025</span></p>
        <h1>中国外贸 B2B<br><span>站群案例库</span></h1>
        <p class="hero-deck">从出口大类找到对标企业。点开真实网站，看工厂和外贸公司如何在不同市场承接选型、打样、询价和经销合作。</p>
        <div class="actions">${button("/industries/", "按品类看研究")}${button("/cases/", "筛选 B2B 案例", true)}</div>
      </div>
      <figure class="hero-media">
        <img src="/images/container-port.webp" alt="蓝调晨光下的集装箱港口示意图" width="1400" height="933" fetchpriority="high">
        <figcaption><span>港口示意</span><span>贸易规模与企业样本</span></figcaption>
      </figure>
    </section>
    <div class="stats-wrap">${countLine()}</div>
    <section class="shell section home-explore">
      <div class="chart-panel">
        <div class="section-heading"><div><p class="eyebrow">出口数据 / 2025</p><h2>重点商品出口额</h2></div><span class="subtle">人民币亿元</span></div>
        ${tradeChart(nationalMetrics.slice(0, 6))}
        <div class="panel-footer"><p>选自国家统计局公报表 11。<br>条形按同一金额刻度绘制。</p>${link("/industries/#trade", "查看完整数据 →", "strong-link")}</div>
      </div>
      <div>
        <div class="section-heading"><div><p class="eyebrow">B2B 样本</p><h2>从这三组开始</h2></div></div>
        <div class="featured-list">${featured.map(item => `<a class="feature" href="${casePath(item)}"><span class="feature-rail" aria-hidden="true"></span><span><b>${escape(item.name)}</b><small>${escape(item.title)}</small></span>${iconArrow()}</a>`).join("")}</div>
        ${link("/cases/", "浏览全部案例 →", "strong-link featured-end")}
      </div>
    </section>
    <section class="section industry-strip">
      <div class="shell">
        <div class="section-heading"><div><p class="eyebrow">产业入口</p><h2>按产品找对标</h2></div>${link("/industries/", "查看全部品类 →", "strong-link")}</div>
        <div class="industry-map">${Object.entries(groups).map(([group, label]) => `<section><h3>${escape(label)}</h3><ul>${industries.filter(item => item.group === group).map(item => `<li>${link(industryPath(item), item.name)}${iconArrow()}</li>`).join("")}</ul></section>`).join("")}</div>
      </div>
    </section>`,
  });
}

function industriesIndex() {
  const introContent = intro("出口数据与企业样本", "按出口品类查看研究", "先比较完整年度的重点商品出口额，再看每类买家找什么、企业网站怎样分工。选择品类可查看案例和原网址。", crumb([{ label: "品类研究" }]));
  const columns = `<thead><tr><th scope="col">商品统计项</th><th scope="col">2025 年出口额</th><th scope="col">金额同比</th><th scope="col">数据来源</th></tr></thead>`;
  const metricsTable = (metrics, label) => `<div class="table-scroll" tabindex="0" role="region" aria-label="${escape(label)}"><table>${columns}<tbody>${metrics.map(metric => `<tr><td>${link(industryPath(metric.industry), metric.item, "strong-link")}</td><td class="table-number">${number.format(metric.amount)} ${escape(metric.unit)}</td><td><span class="change">${signed(metric.growth)}</span></td><td>${external(metric.source, metric.publisher)}</td></tr>`).join("")}</tbody></table></div>`;
  return frame({
    title: `品类研究 | ${siteName}`, description: `${counts.industries} 个重点出口品类的 2025 年出口数据、采购逻辑、中国工厂与外贸独立站案例。`,
    current: "industries", script: true,
    content: introContent + `<section class="section shell" id="categories">
      <div class="section-heading"><h2>选择产业与品类</h2><span class="subtle">${counts.industries} 个研究入口</span></div>
      <div class="group-filter" data-group-filter aria-label="按产业筛选" hidden>
        <button type="button" data-group-choice="" aria-pressed="true">全部</button>
        ${Object.entries(groups).map(([id, label]) => `<button type="button" data-group-choice="${escape(id)}" aria-pressed="false">${escape(label)}</button>`).join("")}
      </div>
      <div class="industry-grid" data-group-grid>${industries.map(industryCard).join("")}</div>
    </section>
    <section class="section section-border shell" id="trade">
      <div class="section-heading"><div><p class="eyebrow">2025 年 / 全年</p><h2>重点商品出口数据</h2></div>${link("/data/export-metrics.csv", "下载统计表 ↓", "strong-link")}</div>
      <p class="prose intro-note">国家统计局公报列示的商品项按出口金额排序。行业报告列在下一张表，各自保留原币种和统计范围。</p>
      <h3 class="table-heading">国家统计局重点商品</h3>
      ${metricsTable(nationalMetrics, "国家统计局重点商品出口")}
      <h3 class="table-heading">补充行业口径</h3>
      ${metricsTable(sectorMetrics, "补充行业出口统计")}
    </section>`,
  });
}

function industryPage(industry) {
  const items = ownCases(industry);
  const sample = items.filter(item => item.structure === "central").length;
  const summary = `${items.length} 组 B2B 网站样本${sample ? `，含 ${sample} 组集中式独立站或工厂官网对照` : ""}。`;
  return frame({
    title: `${industry.name}外贸站群研究 | ${siteName}`, description: industry.scope,
    current: "industries",
    content: intro(groups[industry.group], industry.name, industry.scope, crumb([{ url: "/industries/", label: "品类研究" }, { label: industry.name }]))
      + `<div class="shell detail-grid section">
        <div>
          <section aria-labelledby="trade-heading">
            <div class="section-heading"><h2 id="trade-heading">年度出口规模</h2><span class="subtle">2025 年</span></div>
            <div class="metric-grid">${industry.metrics.map(metric => `<div class="metric-card"><p>${escape(metric.item)}</p><div class="fig">${number.format(metric.amount)} <span>${escape(metric.unit)}</span></div><p class="subtle">金额同比 <span class="change">${signed(metric.growth)}</span></p><div class="metric-source">${external(metric.source, metric.publisher)}</div></div>`).join("")}</div>
          </section>
          <section class="detail-block"><h2>买家根据什么作决定</h2><p>${escape(industry.buyer)}</p></section>
          <section class="detail-block"><h2>同行网站怎样分工</h2><p>${escape(industry.compare)}</p></section>
        </div>
        <aside class="guide-panel"><h2>工厂与外贸公司可以怎么借鉴</h2><p>${escape(industry.apply)}</p><p class="subtle">${escape(summary)}</p>${link(`/cases/?industry=${industry.id}`, "在案例库筛选此品类 →", "strong-link")}</aside>
      </div>
      <section class="section shell section-border"><div class="section-heading"><h2>企业案例</h2><span class="subtle">${items.length} 组</span></div><div class="case-grid">${items.map(card).join("")}</div></section>`,
  });
}

function options(values) {
  return values.map(([id, label]) => `<option value="${escape(id)}">${escape(label)}</option>`).join("");
}

function casesIndex() {
  const preferred = ["jhctech", "tinno", "zhorya", "yuto", "xcmg", "sunon", "hongyu", "junyuan"];
  const order = new Map(preferred.map((id, index) => [id, index]));
  const arranged = [...cases].sort((a, b) => (order.get(a.id) ?? preferred.length) - (order.get(b.id) ?? preferred.length));
  return frame({
    title: `B2B 独立站案例 | ${siteName}`, description: "筛选可公开查看的工厂、外贸公司和海外 B2B 对照案例，按行业、国家、网址结构和采购方式研究。",
    current: "cases", script: true,
    content: intro("制造商与外贸公司", "B2B 独立站案例", "打开每组企业案例，可对照网址、市场、语言、采购入口和运营关系证据。", crumb([{ label: "B2B 案例" }])) 
    + `<section class="section shell" aria-label="案例筛选与结果">
      <form class="filters" data-case-filter role="search" hidden>
        <div><label for="q">搜索企业、国家或域名</label><input type="search" id="q" name="q" placeholder="例如 深圳、德国、OEM、Tinno"></div>
        <div><label for="industry">出口品类</label><select id="industry" name="industry"><option value="">全部品类</option>${options(industries.map(item => [item.id, item.name]))}</select></div>
        <div><label for="structure">网站结构</label><select id="structure" name="structure"><option value="">全部结构</option>${options(Object.entries(structures).map(([id, item]) => [id, item.name]))}</select></div>
        <div><label for="lead">采购入口</label><select id="lead" name="lead"><option value="">全部入口</option>${options(Object.entries(leadTypes))}</select></div>
        <button class="clear" type="reset">清除</button>
      </form>
      <div class="list-meta"><p aria-live="polite" data-result-count>显示 ${cases.length} 组案例</p>${link("/data/b2b-site-links.csv", "下载网址 CSV ↓", "strong-link")}</div>
      <p class="empty" data-empty hidden>没有符合当前条件的案例。可删掉部分关键词或清除筛选。</p>
      <div class="case-grid" data-case-grid>${arranged.map(card).join("")}</div>
    </section>`,
  });
}

function casePage(item) {
  const industry = byIndustry.get(item.industry);
  const related = ownCases(industry).filter(other => other !== item);
  return frame({
    title: `${item.name}外贸独立站案例 | ${siteName}`, description: item.summary,
    current: "cases",
    content: intro(industry.name + " / " + structures[item.structure].name, item.name, item.title, crumb([{url:"/cases/",label:"B2B 案例"},{url:industryPath(industry),label:industry.name},{label:item.name}]))
    + `<div class="shell case-layout section">
      <article>
        <section id="site-links">
          <div class="section-heading"><div><h2>公开网站与页面</h2><p class="subtle">${escape(item.summary)}</p></div></div>
          <div class="site-list">${item.sites.map(site => `<article class="site-item">
             <div class="site-url"><h3>${external(site.url, site.label, "strong-link")}</h3><span>${escape(host(site.url))}</span></div>
             <div class="site-role"><strong>${escape(site.role)}</strong><p>${escape(site.observation)}</p><small>${escape(site.market)} · ${escape(site.language)}</small>${availability(site.url)}</div>
          </article>`).join("")}</div>
        </section>
        ${[["网站如何分工", item.pattern], ["买家如何继续采购", item.path], ["适合工厂借鉴的做法", item.insight], ["证据范围", item.boundary]].map(([title, content]) => `<section class="detail-block"><h2>${escape(title)}</h2><p>${escape(content)}</p></section>`).join("")}
        <section class="detail-block" id="sources"><h2>公开证据</h2><ul class="source-list">${item.sources.map(source => `<li>${external(source.url, source.label, "strong-link")}${availability(source.url)}<p>${escape(source.note)}</p></li>`).join("")}</ul></section>
      </article>
      <aside class="guide-panel">
        <h2>案例资料</h2>
        <dl class="fact-list"><div><dt>采购入口</dt><dd>${escape(leadTypes[item.lead])}</dd></div><div><dt>网站结构</dt><dd>${escape(structures[item.structure].name)}</dd></div><div><dt>证据类型</dt><dd>${escape(evidenceLevels[item.evidence])}</dd></div><div><dt>资料核对</dt><dd><time datetime="${checked}">${checked}</time></dd></div></dl>
        ${link(industryPath(industry), "回到品类研究 →", "strong-link")}
      </aside>
    </div>
    <section class="section shell section-border"><div class="section-heading"><h2>同品类对照</h2></div><div class="case-grid">${related.map(card).join("")}</div></section>`,
  });
}

function method() {
  return frame({
    title: `研究方法与出处 | ${siteName}`, description: "出口金额、B2B 站群、企业公开证据与业务结论的研究范围。",
    current: "method",
    content: intro("数据来源与证据边界", "研究方法", "从官方出口商品项选行业，再用企业公开页面和组织关系证据判断网站如何服务买家。", crumb([{ label: "研究方法" }]))
      + `<div class="shell case-layout section">
      <article class="reading">
        <section class="detail-block"><h2>怎样选品类</h2>
          <p>使用 2025 完整年度，便于把金额与上年同期比较。国家统计局公报表 10 显示，中国货物出口 ${number.format(tradeTotal)} 亿元，同比 ${signed(tradeGrowth)}，其中机电产品 ${number.format(electricalTotal)} 亿元，占 ${(electricalTotal/tradeTotal*100).toFixed(1)}%。表 11 的全部 14 个商品项和补充行业报告用于选题。品类是研究入口，部分品类并列相关商品项，数据表按各来源原始口径展示。</p>
          <p>工程机械、橡胶轮胎、光伏和家用电器使用行业组织公布的海关口径。每项留原币种和范围，涉及相邻产业的案例在行业页说明。</p>
          <div class="inline-links">${external(nbs, "国家统计局 2025 年公报")}${external(nbsEnglish, "公报表 10 与 11（英文）")}${link("/industries/#trade", "品类统计表 →", "strong-link")}</div>
        </section>
        <section class="detail-block"><h2>怎样判断是外贸 B2B 网站</h2>
          <p>选取工厂、生产企业或外贸公司自己的公开网站，优先保留 OEM/ODM、批量报价、技术选型、项目采购、海外经销或交付服务入口。独立站可用企业品牌、独立国家域，也可用同一主域下的子域或目录。当地渠道站注明厂家与经营方的关系。</p>
          <p>关系优先看企业导航、公开主体声明、母子公司披露、地区公司页和经销协议。企业自述的产能、资质、出口国家数与供应关系只按证据范围列出。采购前应对负责签约、生产和售后的具体主体另行核实。</p>
        </section>
        <section class="detail-block"><h2>怎样辨别网站结构</h2>
          <dl class="definition-list">${Object.values(structures).map(item => `<div><dt>${escape(item.name)}</dt><dd>${escape(item.detail)}</dd></div>`).join("")}</dl>
          <p>目录和子域中的语言版提供独立网址路径。国家后缀则提供明确的地域信号，具体效果要与语言内容、技术、竞争及企业经营结合阅读。</p>
          <div class="inline-links">${external(seoSource, "Google 多地区与多语言网站指南")}</div>
        </section>
        <section class="detail-block"><h2>跨品类看到的三种采购入口</h2>
          <dl class="definition-list">
            <div><dt>规格与技术文件</dt><dd>工控机、芯片、光伏和轮胎需要按型号保留规格差异。集和诚、兆易创新及晶科展示了语言版、技术站和不同地区文件的三种组织方式。</dd></div>
            <div><dt>询价、打样与工厂职责</dt><dd>包装、纺织、服装、鞋靴及箱包需要先确认材料与订单条件。宏裕、Yotex、君源可对照买家该提供什么，以及由工厂还是贸易端接洽。</dd></div>
            <div><dt>经销和交付服务</dt><dd>重型设备、商用车和办公项目依赖线下服务。徐工、宇通和圣奥的当地页把产品连接到经销、服务站或实体展厅。</dd></div>
          </dl>
        </section>
        <section class="detail-block"><h2>这次核对覆盖了什么</h2>
          <p>选取 ${counts.cases} 组可查样本，按结构与采购行为比较。公开页面可见的网站作用，以及根据采购过程提出的借鉴做法，分别写在案例中。资料核对以企业网页、原始披露和既有证据为基础。标有“直连访问受限”或“直连未读到”的网址，在 ${checked} 的访问检查中遇到拒绝或超时，可结合页面所列的公开证据阅读。</p>
          <p>本文研究全国商品出口规模与企业如何组织页面。实际网站询盘、流量、订单、客户数据和各国绩效需要运营者提供。样本用于选择对标与验证公开结构。</p>
        </section>
      </article>
      <aside class="guide-panel">
        <h2>可下载数据</h2>
        <p>按品类和案例查看站点网址、市场、语言与用途。统计表保留金额、币种、同比和来源。</p>
        <div class="download-list">${link("/data/b2b-site-links.csv", "案例网址 CSV ↓", "strong-link")}${link("/data/export-metrics.csv", "出口指标 CSV ↓", "strong-link")}</div>
      </aside>
    </div>`,
  });
}

function write(rootPath, name, contents) {
  const target = join(rootPath, name);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, contents);
}

function csv(rows) {
  return "\uFEFF" + rows.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n") + "\r\n";
}

function assertData() {
  const seen = new Set();
  for (const item of [...industries, ...cases]) {
    if (seen.has(item.id) || !/^[a-z0-9-]+$/.test(item.id)) throw Error(`Invalid or duplicate id: ${item.id}`);
    seen.add(item.id);
  }
  for (const item of industries) {
    if (!groups[item.group] || !item.metrics.length || ownCases(item).length < 2) throw Error(`Incomplete industry ${item.id}`);
    for (const metric of item.metrics) {
      if (!Number.isFinite(metric.amount) || !Number.isFinite(metric.growth)) throw Error(`Invalid metric ${metric.item}`);
    }
  }
  for (const item of cases) {
    if (!byIndustry.has(item.industry) || !structures[item.structure] || !leadTypes[item.lead] || !evidenceLevels[item.evidence]) throw Error(`Invalid case: ${item.id}`);
    if (!item.sites.length || !item.sources.length || !item.insight || !item.boundary) throw Error(`Incomplete case: ${item.id}`);
    for (const entry of [...item.sites, ...item.sources]) {
      const url = new URL(entry.url);
      if (url.protocol !== "https:" || url.username || url.password || /token=|X-Amz-.*=|api-key=/i.test(url.search)) throw Error(`Unsafe or invalid URL in ${item.id}`);
    }
  }
}

assertData();
const tmp = mkdtempSync(join(root, ".stage-"));
try {
  cpSync(join(root, "public"), tmp, { recursive: true });
  write(tmp, "index.html", home());
  write(tmp, "industries/index.html", industriesIndex());
  for (const item of industries) write(tmp, `industries/${item.id}/index.html`, industryPage(item));
  write(tmp, "cases/index.html", casesIndex());
  for (const item of cases) write(tmp, `cases/${item.id}/index.html`, casePage(item));
  write(tmp, "methodology/index.html", method());
  write(tmp, "404.html", frame({
    title: `页面未找到 | ${siteName}`, description: "可从品类或案例索引查看有效入口。", robots: "noindex",
    content: `<section class="shell not-found"><h1>页面未找到</h1><p>从品类或案例索引继续查找。</p><div class="actions">${button("/industries/", "品类研究")}${button("/cases/", "浏览案例", true)}</div></section>`,
  }));
  write(tmp, "data/b2b-site-links.csv", csv([
    ["案例ID", "品类", "企业", "网站结构", "采购入口", "页面", "网址", "市场", "语言", "角色", "页面观察", "直连状态备注", "对应来源"],
    ...cases.flatMap(item => item.sites.map(site => [
      item.id, byIndustry.get(item.industry).name, item.name, structures[item.structure].name, leadTypes[item.lead],
      site.label, site.url, site.market, site.language, site.role, site.observation, linkAvailability[site.url] || "", item.sources.map(source => source.url).join(" | "),
    ])),
  ]));
  write(tmp, "data/export-metrics.csv", csv([
    ["年度", "品类", "商品或行业口径", "金额", "单位", "金额同比%", "来源机构", "来源网址"],
    ...[...nationalMetrics, ...sectorMetrics].map(metric => ["2025", metric.industry.name, metric.item, metric.amount, metric.unit, metric.growth, metric.publisher, metric.source]),
  ]));
  rmSync(join(root, "dist"), { recursive: true, force: true });
  renameSync(tmp, join(root, "dist"));
} finally {
  rmSync(tmp, { recursive: true, force: true });
}
console.log(JSON.stringify({ ...counts, exportIndicators: nationalMetrics.length + sectorMetrics.length, pages: industries.length + cases.length + 5 }));
