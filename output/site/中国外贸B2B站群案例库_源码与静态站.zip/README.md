# 中国外贸 B2B 站群案例库

按中国重点出口商品研究工厂和外贸公司的公开网站。品类页提供原始统计口径、采购方式和网站对照。企业页提供网址、使用语言、市场、采购入口与证据。

## 网站地址与运行

[打开已发布的网站](https://china-export-network-atlas.1314jackzhang.workers.dev/)

- Cloudflare Workers 项目名为 `china-export-network-atlas`。
- Node.js 22 或更新版本可运行构建和预览。源码没有第三方构建依赖。
- `npm run check` 先生成静态网站，再核对页面、内部链接、案例网址与两份 CSV。
- `npm run preview` 在本机提供预览，默认地址为 `http://127.0.0.1:8787/`。
- 在已登录 Cloudflare 的环境中运行 `npm run deploy` 部署。该命令使用已安装的 Wrangler。发布目录为 `dist/`，部署设置位于 `wrangler.jsonc`。
- 部署后访问根页、案例详情、CSV 下载和一个不存在的路由，检查后者返回 HTTP 404。

## 内容维护

- `content/industries.mjs` 维护品类及统计来源。全国货物出口和 14 个重点商品项使用国家统计局 2025 年公报。行业协会或研究院的 4 个统计项按来源保留币种及范围。
- `content/cases-*.mjs` 维护案例。每组至少有一个网站采购入口与明确来源，页面区分公开观察、采购分析与可借鉴做法。
- 补充国家域名时，应先核对当地实际运营方。把集团自营、经销网站、独立业务域、同域多语和集中式单站按证据标记。域名跳转或外站暂时受限时，应核对最终页面、官方声明和可读来源。
- 两份下载表由构建自动生成，可从品类和案例页取用。
- 首页的集装箱港口图为 ImageGen 生成的说明性图片，图像位于 `public/images/container-port.webp`。
