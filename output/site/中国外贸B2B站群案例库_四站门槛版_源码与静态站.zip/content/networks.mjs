import { equipmentNetworks } from "./networks-equipment.mjs";
import { manufacturingNetworks } from "./networks-manufacturing.mjs";

export const cases = [...equipmentNetworks, ...manufacturingNetworks];
